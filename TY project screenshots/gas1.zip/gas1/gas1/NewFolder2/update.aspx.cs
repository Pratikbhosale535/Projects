﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace gas1.NewFolder2
{
    public partial class update1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["custid"] != null)
            {
                custid.Text = Session["custid"] + "";
            }  
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          //  string strConn = "Data Source=abc-pc\\sql;Initial Catalog=gas;Integrated Security=True";
            string strConn = WebConfigurationManager.ConnectionStrings["gasConnectionString"].ConnectionString;

            SqlConnection objConn = new SqlConnection(strConn);


            try
            {

                String strQuery = "update register1 set fname=@fname,lname=@lname,username=@username,password=@password,cpassword=@cpassword,email=@email,mn=@mn,question=@question,ans=@ans where custid=@custid";
                SqlCommand objCmd = new SqlCommand(strQuery, objConn);
                objCmd.Parameters.AddWithValue("@custid", custid.Text);
                objCmd.Parameters.AddWithValue("@fname", fname.Text);
                objCmd.Parameters.AddWithValue("@lname", lname.Text);
                objCmd.Parameters.AddWithValue("@username", username.Text);
                objCmd.Parameters.AddWithValue("@password", password.Text);
                objCmd.Parameters.AddWithValue("@cpassword", cpassword.Text);
                objCmd.Parameters.AddWithValue("@email", email.Text);
                objCmd.Parameters.AddWithValue("@mn", mn.Text);
                objCmd.Parameters.AddWithValue("@question", ddl.SelectedItem.Value);
                objCmd.Parameters.AddWithValue("@ans", ans.Text);
                objConn.Open();
                objCmd.ExecuteNonQuery();

                lbl.Text = "Booking cancel successfully";

            }
            catch
            {
                lbl.Text = "cancel booking failed";
            }
            objConn.Close();


        }

       
    }
}