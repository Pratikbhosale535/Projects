﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Configuration;

namespace gas1.NewFolder2
{
    public partial class newconnection : System.Web.UI.Page
    {
        // string strConnString = "Data Source=abc-pc\\sql;Initial Catalog=gas;Integrated Security=True";
       string strConnString = WebConfigurationManager.ConnectionStrings["gasConnectionString"].ConnectionString;
        string str;

        SqlCommand com;
        int count;
        protected void Page_Load(object sender, EventArgs e)
        {
       
            if (Session["custid"] != null)
            {
                custid.Text = Session["custid"] + "";
            }
            SqlConnection con = new SqlConnection(strConnString);

            str = "select count(*) from nconnection1";

            com = new SqlCommand(str, con);

            con.Open();

            count = Convert.ToInt16(com.ExecuteScalar()) + 1;

            connectionid.Text = "CN3452" + count;

            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bool inputIsValid = true;
            try
            {
                var con = new SqlConnection(WebConfigurationManager.ConnectionStrings["gasConnectionString"].ConnectionString);
                var custidcmd = new SqlCommand("SELECT 1 FROM nconnection1 WHERE custid = @custid ", con);
                var emailCmd = new SqlCommand("SELECT 1 FROM nconnection1 WHERE email = @email", con);

                con.Open();
                custidcmd.Parameters.AddWithValue("@custid", custid.Text);
                emailCmd.Parameters.AddWithValue("@email", email.Text);

                using (var custidReader = custidcmd.ExecuteReader())
                {
                     if (custidReader.HasRows)
                    {
                        inputIsValid = false;
                        lbl.Text = "Customer Id already exists, You have already an account";
                    }
                }
                using (var emailReader = emailCmd.ExecuteReader())
                {
                      if (emailReader.HasRows)
                    {
                        inputIsValid = false;
                        lbl.Text = "Email address already exists Please enter other Email";
                    }
                }

                if (inputIsValid)
                {
                    str = "insert into nconnection1 values(@custid,@connectionid,@fname,@lname,@address,@aadhaar,@mno,@email,@category)";

                    com = new SqlCommand(str, con);
                    com.Parameters.AddWithValue("@custid", custid.Text);
                    com.Parameters.AddWithValue("@connectionid", connectionid.Text);
                    com.Parameters.AddWithValue("@fname", fname.Text);
                    com.Parameters.AddWithValue("@lname", lname.Text);
                  //  com.Parameters.AddWithValue("@account", account.Text);
                    com.Parameters.AddWithValue("@address", address.Text);
                    com.Parameters.AddWithValue("@aadhaar", aadhaar.Text);
                    com.Parameters.AddWithValue("@mno", mno.Text);
                    com.Parameters.AddWithValue("@email", email.Text);
                    com.Parameters.AddWithValue("@category", rb.SelectedValue);

                    com.ExecuteNonQuery();
                    lbl.Text = "CONNECTION ADDED SUCCESSFULLY, NOW YOU CAN BOOK GAS";

                } con.Close();
            } 
            catch
          { lbl.Text = "rrrr";}

           

        }


        }
    }
